<?php $__currentLoopData = $html; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php echo $item; ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH /var/www/html/mvs.bslmeiyu.com/vendor/encore/laravel-admin/src/../resources/views/partials/html.blade.php ENDPATH**/ ?>